const API_URL = 'http://localhost:8080/todos';
const form = document.getElementById('task-form');
const nome = document.getElementById('nome');
const descricao = document.getElementById('descricao');
const prioridade = document.getElementById('prioridade');
const realizado = document.getElementById('realizado');
const taskList = document.getElementById('task-list');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const tarefa = {
    nome: nome.value,
    descricao: descricao.value,
    prioridade: parseInt(prioridade.value),
    realizado: realizado.checked
  };
  await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(tarefa)
  });
  form.reset();
  loadTasks();
});

async function loadTasks() {
  const response = await fetch(`${API_URL}/1`);
  const tarefas = await response.json();
  taskList.innerHTML = '';
  tarefas.forEach(todo => {
    const li = document.createElement('li');
    li.innerHTML = `
      <strong>${todo.nome}</strong><br />
      ${todo.descricao} - Prioridade: ${todo.prioridade} - ${todo.realizado ? '✅' : '❌'}
      <button onclick="deleteTask(${todo.id})">Excluir</button>
    `;
    taskList.appendChild(li);
  });
}

async function deleteTask(id) {
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
  loadTasks();
}
loadTasks();